package com.example.shoppingcartstore.ui.local

import java.io.Serializable

data class CategoryDataClass(
    var img: Int,
    var categoryName: String,
) : Serializable
