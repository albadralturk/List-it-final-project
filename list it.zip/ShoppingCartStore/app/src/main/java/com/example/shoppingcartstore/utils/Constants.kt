package com.example.shoppingcartstore.utils

const val LOG_IN_PREF_KEY = "LOG_IN_PREF"
const val LOGOUT_PREF_KEY = "LOGOUT_PREF"
const val CATEGORY_SERI_INTENT_KEY = "CATEGORY_SERI_INTENT"
const val TITLE_NAME_INTENT_KEY = "TITLE_NAME"